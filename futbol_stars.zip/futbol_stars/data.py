"""Futbol Stars - ma'lumotlar: kartalar, jamoalar, saqlash va turnir mantiqi."""
import datetime
import json
import math
import os
import random
import uuid

SAVE_PATH = os.environ.get(
    "FUTBOL_SAVE", os.path.join(os.path.expanduser("~"), ".futbol_stars_save.json")
)

SLOTS = ["GK", "DEF", "DEF", "MID", "FWD"]
USER_NAME = "Mening jamoam"
USER_COLOR = (36, 104, 235)

FIRST = ["Aziz", "Bobur", "Jasur", "Sardor", "Otabek", "Dilshod", "Rustam", "Umid",
         "Eldor", "Farhod", "Timur", "Sherzod", "Anvar", "Behruz", "Jahongir", "Kamol",
         "Laziz", "Nodir", "Oybek", "Ravshan", "Samir", "Ulugbek", "Zafar", "Akmal",
         "Diyor", "Hasan", "Ilhom", "Mirza", "Nurbek", "Sanjar"]
LAST = ["Karimov", "Aliyev", "Rahimov", "Yusupov", "Tursunov", "Nazarov", "Qodirov",
        "Abdullaev", "Ergashev", "Ismoilov", "Mirzaev", "Saidov", "Hamidov", "Normatov",
        "Olimov", "Rasulov", "Sobirov", "Toshev", "Umarov", "Valiyev", "Xolmatov",
        "Yoqubov", "Zokirov", "Bekov", "Davronov", "Fayziev", "Gafurov", "Haydarov"]

# (nomi, rangi, reyting)  - barcha klublar to'qima
AI_TEAMS = [
    ("Registon FK", (205, 45, 45), 64),
    ("Xiva Shamol", (240, 190, 40), 62),
    ("Buxoro Qalqon", (40, 150, 150), 68),
    ("Farg'ona Olov", (240, 120, 30), 70),
    ("Namangan Burgut", (150, 90, 200), 72),
    ("Nukus Bo'ron", (60, 180, 90), 74),
    ("Andijon Bars", (220, 70, 150), 77),
    ("Toshkent Yulduz", (235, 235, 235), 80),
]

PACKS = [
    # nomi, narxi, daraja indeksi, rangi
    ("Bronza paket", 600, 0, (176, 112, 60)),
    ("Kumush paket", 1800, 1, (190, 200, 214)),
    ("Oltin paket", 4500, 2, (238, 194, 52)),
]
PACK_RANGES = [
    [((50, 64), 60), ((65, 74), 35), ((75, 84), 5)],
    [((58, 64), 25), ((65, 74), 55), ((75, 84), 19), ((85, 90), 1)],
    [((65, 74), 30), ((75, 84), 55), ((85, 93), 15)],
]
POS_WEIGHTS = [("GK", 14), ("DEF", 28), ("MID", 29), ("FWD", 29)]
PRIZES = [5000, 3000, 1800, 1000, 600, 400]
DAILY_GIFT = 800

RAR_COL = {
    "BRONZA": (176, 112, 60),
    "KUMUSH": (190, 200, 214),
    "OLTIN": (238, 194, 52),
    "ELITA": (130, 90, 240),
}


def rarity(ovr):
    if ovr >= 85:
        return "ELITA"
    if ovr >= 75:
        return "OLTIN"
    if ovr >= 65:
        return "KUMUSH"
    return "BRONZA"


def sell_value(card):
    return int((card["ovr"] - 45) ** 2 * 0.25 + 20)


def make_card(pos, ovr):
    ovr = int(max(40, min(96, ovr)))

    def j(v):
        return int(max(25, min(99, v + random.randint(-6, 6))))

    if pos == "GK":
        s = (ovr - 14, ovr - 30, ovr - 10, ovr + 3)
    elif pos == "DEF":
        s = (ovr - 5, ovr - 18, ovr - 6, ovr + 6)
    elif pos == "MID":
        s = (ovr - 3, ovr - 6, ovr + 6, ovr - 8)
    else:
        s = (ovr + 3, ovr + 6, ovr - 6, ovr - 26)
    pac, sho, pas, dfn = [j(v) for v in s]
    return {
        "id": uuid.uuid4().hex[:10],
        "name": "%s. %s" % (random.choice(FIRST)[0], random.choice(LAST)),
        "pos": pos, "ovr": ovr, "pac": pac, "sho": sho, "pas": pas, "dfn": dfn,
    }


def make_team_cards(rating):
    return [make_card(pos, rating + random.randint(-3, 3)) for pos in SLOTS]


def _weighted(pairs):
    total = sum(w for _, w in pairs)
    r = random.uniform(0, total)
    acc = 0
    for item, w in pairs:
        acc += w
        if r <= acc:
            return item
    return pairs[-1][0]


def roll_pack(kind):
    cards = []
    for _ in range(3):
        lo, hi = _weighted(PACK_RANGES[kind])
        cards.append(make_card(_weighted(POS_WEIGHTS), random.randint(lo, hi)))
    return cards


# ----------------------------------------------------------------- saqlash
def new_save():
    cards = [make_card("GK", 58), make_card("DEF", 57), make_card("DEF", 55),
             make_card("MID", 60), make_card("FWD", 61)]
    cards += [make_card(random.choice(["DEF", "MID", "FWD"]), random.randint(50, 58))
              for _ in range(3)]
    return {
        "coins": 3000,
        "cards": cards,
        "squad": [c["id"] for c in cards[:5]],
        "settings": {"difficulty": 1, "length": 120, "sound": True},
        "tournament": None,
        "stats": {"played": 0, "won": 0, "drawn": 0, "lost": 0, "gf": 0, "ga": 0},
        "titles": 0,
        "daily": "",
    }


def fix_squad(save):
    by_id = {c["id"]: c for c in save["cards"]}
    squad = list(save.get("squad", []))[:5]
    while len(squad) < 5:
        squad.append(None)
    used = set()
    for i, pos in enumerate(SLOTS):
        cid = squad[i]
        if cid in by_id and by_id[cid]["pos"] == pos and cid not in used:
            used.add(cid)
            continue
        pool = [c for c in save["cards"] if c["pos"] == pos and c["id"] not in used]
        if not pool:
            c = make_card(pos, 50)
            save["cards"].append(c)
            pool = [c]
        best = max(pool, key=lambda c: c["ovr"])
        squad[i] = best["id"]
        used.add(best["id"])
    save["squad"] = squad


def load_save():
    try:
        with open(SAVE_PATH, "r", encoding="utf-8") as f:
            save = json.load(f)
        base = new_save()
        for k, v in base.items():
            save.setdefault(k, v)
        for k, v in base["settings"].items():
            save["settings"].setdefault(k, v)
        for k, v in base["stats"].items():
            save["stats"].setdefault(k, v)
        fix_squad(save)
        return save
    except Exception:
        return new_save()


def write_save(save):
    try:
        with open(SAVE_PATH, "w", encoding="utf-8") as f:
            json.dump(save, f, ensure_ascii=False)
    except Exception:
        pass


def squad_cards(save):
    by_id = {c["id"]: c for c in save["cards"]}
    return [by_id[i] for i in save["squad"]]


def squad_rating(save):
    cs = squad_cards(save)
    return int(round(sum(c["ovr"] for c in cs) / len(cs)))


def best_squad(save):
    used = set()
    squad = []
    for pos in SLOTS:
        pool = [c for c in save["cards"] if c["pos"] == pos and c["id"] not in used]
        if not pool:
            squad.append(None)
            continue
        b = max(pool, key=lambda c: c["ovr"])
        used.add(b["id"])
        squad.append(b["id"])
    if None not in squad:
        save["squad"] = squad


def daily_available(save):
    return save.get("daily", "") != datetime.date.today().isoformat()


def claim_daily(save):
    if not daily_available(save):
        return False
    save["daily"] = datetime.date.today().isoformat()
    save["coins"] += DAILY_GIFT
    return True


# ------------------------------------------------------------------ turnir
def round_robin(n):
    teams = list(range(n))
    rounds = []
    for _ in range(n - 1):
        rounds.append([(teams[i], teams[n - 1 - i]) for i in range(n // 2)])
        teams = [teams[0]] + [teams[-1]] + teams[1:-1]
    return rounds


def new_tournament():
    opps = random.sample(AI_TEAMS, 5)
    teams = [{"name": USER_NAME, "color": list(USER_COLOR), "rating": 0}]
    for n, c, r in opps:
        teams.append({"name": n, "color": list(c), "rating": r})
    return {
        "teams": teams,
        "schedule": round_robin(6),
        "round": 0,
        "table": [{"p": 0, "w": 0, "d": 0, "l": 0, "gf": 0, "ga": 0, "pts": 0} for _ in range(6)],
        "done": False, "place": 0, "prize": 0,
    }


def poisson(lam):
    limit = math.exp(-lam)
    k, p = 0, 1.0
    while True:
        p *= random.random()
        if p <= limit or k > 8:
            return k
        k += 1


def sim_score(ra, rb):
    la = max(0.4, 1.35 + (ra - rb) * 0.045)
    lb = max(0.4, 1.35 - (ra - rb) * 0.045)
    return poisson(la), poisson(lb)


def _apply(t, a, b, ga, gb):
    ra, rb = t["table"][a], t["table"][b]
    ra["p"] += 1
    rb["p"] += 1
    ra["gf"] += ga
    ra["ga"] += gb
    rb["gf"] += gb
    rb["ga"] += ga
    if ga > gb:
        ra["w"] += 1
        ra["pts"] += 3
        rb["l"] += 1
    elif ga < gb:
        rb["w"] += 1
        rb["pts"] += 3
        ra["l"] += 1
    else:
        ra["d"] += 1
        rb["d"] += 1
        ra["pts"] += 1
        rb["pts"] += 1


def standings(t):
    return sorted(range(len(t["teams"])),
                  key=lambda i: (t["table"][i]["pts"],
                                 t["table"][i]["gf"] - t["table"][i]["ga"],
                                 t["table"][i]["gf"]),
                  reverse=True)


def next_opponent(t):
    if t["done"]:
        return None
    for a, b in t["schedule"][t["round"]]:
        if a == 0:
            return b
        if b == 0:
            return a
    return None


def finish_round(t, user_rating, ugf, uga):
    """Foydalanuvchi o'yinini qo'shadi, qolganlarini simulyatsiya qiladi. Mukofotni qaytaradi."""
    t["teams"][0]["rating"] = user_rating
    for a, b in t["schedule"][t["round"]]:
        if a == 0:
            _apply(t, a, b, ugf, uga)
        elif b == 0:
            _apply(t, a, b, uga, ugf)
        else:
            ga, gb = sim_score(t["teams"][a]["rating"], t["teams"][b]["rating"])
            _apply(t, a, b, ga, gb)
    t["round"] += 1
    if t["round"] >= len(t["schedule"]):
        t["done"] = True
        t["place"] = standings(t).index(0) + 1
        t["prize"] = PRIZES[t["place"] - 1]
        return t["prize"]
    return 0
