"""Futbol Stars - Pygame'da yozilgan to'liq futbol o'yini.  Ishga tushirish: python main.py"""
import random
import sys

import pygame
from pygame.locals import (K_BACKSPACE, K_DOWN, K_ESCAPE, K_F11, K_KP_ENTER, K_LEFT, K_RETURN,
                           K_RIGHT, K_SPACE, K_UP, K_a, K_d, K_s, K_w, KEYDOWN, MOUSEBUTTONDOWN,
                           MOUSEMOTION, QUIT)

import data
import ui
from match import Match
from sfx import Sfx
from ui import SH, SW, background, coins_badge, draw_card, draw_menu, footer, panel, text, title

ENTER = (K_RETURN, K_KP_ENTER)
LENGTHS = [60, 90, 120, 180, 240]
DIFF_NAMES = ["Oson", "O'rtacha", "Qiyin"]


class App:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SW, SH), pygame.SCALED | pygame.RESIZABLE)
        pygame.display.set_caption("Futbol Stars")
        self.clock = pygame.time.Clock()
        self.save = data.load_save()
        self.sfx = Sfx()
        self.sfx.enabled = self.save["settings"]["sound"]
        self.t = 0.0
        self.scene = None
        self.go(MenuScene)

    def go(self, cls, *args):
        self.scene = cls(self, *args)

    def persist(self):
        data.write_save(self.save)

    def quit(self):
        self.persist()
        pygame.quit()
        sys.exit()

    def frame(self, dt, events):
        self.t += dt
        for ev in events:
            if ev.type == QUIT:
                self.quit()
            if ev.type == KEYDOWN and ev.key == K_F11:
                try:
                    pygame.display.toggle_fullscreen()
                except Exception:
                    pass
                continue
            self.scene.handle(ev)
        self.scene.update(dt)
        self.scene.draw(self.screen)

    def run(self):
        while True:
            dt = min(self.clock.tick(60) / 1000.0, 0.05)
            self.frame(dt, pygame.event.get())
            pygame.display.flip()

    def start_match(self, opp_name, opp_color, opp_rating, mode, tour=None):
        s = self.save
        m = Match(data.squad_cards(s), data.make_team_cards(opp_rating), data.USER_COLOR,
                  opp_color, data.USER_NAME, opp_name, s["settings"]["length"],
                  s["settings"]["difficulty"], self.sfx)
        self.go(MatchScene, m, mode)


# --------------------------------------------------------------------------- menyu
class MenuScene:
    ITEMS = [("Tezkor o'yin", "Istalgan jamoaga qarshi o'ynang"),
             ("Turnir", "5 ta o'yin, kubok va katta mukofot"),
             ("Jamoa tuzish", "Kartalaringizdan tarkib tanlang"),
             ("Do'kon", "Futbolchi paketlarini oching"),
             ("Sozlamalar", "Qiyinlik, davomiylik, ovoz"),
             ("Chiqish", "")]

    def __init__(self, app):
        self.app = app
        self.sel = 0
        self.rects = []

    def choose(self):
        a = self.app
        if self.sel == 5:
            a.quit()
        a.go([QuickScene, TournamentScene, SquadScene, ShopScene, SettingsScene][self.sel])

    def handle(self, ev):
        if ev.type == KEYDOWN:
            if ev.key in (K_UP, K_w):
                self.sel = (self.sel - 1) % len(self.ITEMS)
                self.app.sfx.play("click")
            elif ev.key in (K_DOWN, K_s):
                self.sel = (self.sel + 1) % len(self.ITEMS)
                self.app.sfx.play("click")
            elif ev.key in ENTER or ev.key == K_SPACE:
                self.choose()
        elif ev.type == MOUSEMOTION:
            for i, r in enumerate(self.rects):
                if r.collidepoint(ev.pos):
                    self.sel = i
        elif ev.type == MOUSEBUTTONDOWN and ev.button == 1:
            for i, r in enumerate(self.rects):
                if r.collidepoint(ev.pos):
                    self.sel = i
                    self.choose()

    def update(self, dt):
        pass

    def draw(self, surf):
        a = self.app
        s = a.save
        background(surf, a.t)
        text(surf, "FUTBOL STARS", 84, (255, 236, 150), (SW // 2, 70), "center", True, shadow=True)
        text(surf, "Mobil uslubdagi futbol  -  to'liq versiya", 24, (180, 205, 235),
             (SW // 2, 128), "center")
        import math
        bx = SW // 2 - 330
        by = 330 + math.sin(a.t * 3) * 18
        ui.draw_ball(surf, bx, by, 44, a.t * 2)
        self.rects = draw_menu(surf, [i[0] for i in self.ITEMS], self.sel, SW // 2, 180)
        coins_badge(surf, s["coins"])
        st = s["stats"]
        panel(surf, (SW - 330, 200, 290, 250), alpha=170)
        rows = [("Jamoa reytingi", data.squad_rating(s)), ("O'yinlar", st["played"]),
                ("G'alabalar", st["won"]), ("Durranglar", st["drawn"]),
                ("Mag'lubiyatlar", st["lost"]), ("Turnir kubogi", s["titles"])]
        for i, (k, v) in enumerate(rows):
            text(surf, k, 20, (180, 200, 225), (SW - 312, 216 + i * 38))
            text(surf, v, 22, (255, 255, 255), (SW - 56, 216 + i * 38), "topright", True)
        desc = self.ITEMS[self.sel][1]
        if desc:
            text(surf, desc, 22, (200, 220, 240), (SW // 2, 180 + 6 * 66 + 6), "center")
        footer(surf, "Yuqori/Past - tanlash   |   Enter - kirish   |   F11 - to'liq ekran")


# ---------------------------------------------------------------------- tezkor o'yin
class QuickScene:
    def __init__(self, app):
        self.app = app
        self.i = 0

    def handle(self, ev):
        if ev.type != KEYDOWN:
            return
        n = len(data.AI_TEAMS)
        if ev.key in (K_LEFT, K_a):
            self.i = (self.i - 1) % n
        elif ev.key in (K_RIGHT, K_d):
            self.i = (self.i + 1) % n
        elif ev.key in (K_UP, K_w):
            self.i = (self.i - 4) % n
        elif ev.key in (K_DOWN, K_s):
            self.i = (self.i + 4) % n
        elif ev.key == pygame.K_TAB or ev.key == pygame.K_x:
            st = self.app.save["settings"]
            st["difficulty"] = (st["difficulty"] + 1) % 3
            self.app.persist()
        elif ev.key in ENTER:
            name, col, rating = data.AI_TEAMS[self.i]
            self.app.start_match(name, col, rating, "quick")
        elif ev.key == K_ESCAPE:
            self.app.go(MenuScene)
        if ev.key in (K_LEFT, K_RIGHT, K_UP, K_DOWN, K_a, K_d, K_w, K_s):
            self.app.sfx.play("click")

    def update(self, dt):
        pass

    def draw(self, surf):
        a = self.app
        background(surf, a.t)
        title(surf, "Tezkor o'yin", "Raqibni tanlang")
        coins_badge(surf, a.save["coins"])
        for i, (name, col, rating) in enumerate(data.AI_TEAMS):
            r = pygame.Rect(70 + (i % 4) * 300, 150 + (i // 4) * 150, 270, 125)
            panel(surf, r, alpha=190, border=(255, 230, 60) if i == self.i else (70, 100, 150),
                  width=4 if i == self.i else 2)
            pygame.draw.rect(surf, col, (r.x + 16, r.y + 18, 14, 60), border_radius=5)
            text(surf, name, 24, (255, 255, 255), (r.x + 44, r.y + 20), "topleft", True)
            text(surf, "Reyting: %d" % rating, 20, (190, 210, 235), (r.x + 44, r.y + 58))
            text(surf, "*" * max(1, (rating - 55) // 5), 22, (240, 190, 40), (r.x + 44, r.y + 88))
        st = a.save["settings"]
        panel(surf, (70, 470, 1140, 150), alpha=180)
        text(surf, "Sizning jamoangiz reytingi: %d" % data.squad_rating(a.save), 26, (255, 255, 255),
             (100, 495), "topleft", True)
        text(surf, "Qiyinlik: %s   (Tab - almashtirish)" % DIFF_NAMES[st["difficulty"]], 24,
             (255, 230, 120), (100, 540), "topleft", True)
        text(surf, "O'yin davomiyligi: %d soniya   (Sozlamalarda o'zgartiring)" % st["length"], 22,
             (190, 210, 235), (100, 580), "topleft")
        footer(surf, "Strelkalar - raqib   |   Tab - qiyinlik   |   Enter - boshlash   |   Esc - orqaga")


# --------------------------------------------------------------------------- o'yin
class MatchScene:
    def __init__(self, app, match, mode):
        self.app = app
        self.m = match
        self.mode = mode

    def handle(self, ev):
        self.m.handle_event(ev)

    def update(self, dt):
        m = self.m
        m.update(dt, pygame.key.get_pressed())
        a = self.app
        if m.quit:
            if self.mode == "tour":
                t = a.save["tournament"]
                data.finish_round(t, data.squad_rating(a.save), 0, 3)
                a.persist()
                a.go(TournamentScene)
            else:
                a.go(MenuScene)
        elif m.finished:
            a.go(ResultScene, m, self.mode)

    def draw(self, surf):
        self.m.draw(surf)


class ResultScene:
    def __init__(self, app, m, mode):
        self.app = app
        self.m = m
        self.mode = mode
        s = app.save
        gf, ga = m.score
        res = "win" if gf > ga else "draw" if gf == ga else "loss"
        if mode == "tour":
            base = {"win": 600, "draw": 250, "loss": 100}[res]
            per = 50
        else:
            base = {"win": 400, "draw": 150, "loss": 60}[res]
            per = 40
        self.lines = [({"win": "G'alaba", "draw": "Durrang", "loss": "Mag'lubiyat"}[res], base),
                      ("Urilgan gollar (%d)" % gf, gf * per)]
        st = s["stats"]
        st["played"] += 1
        st["won" if res == "win" else "drawn" if res == "draw" else "lost"] += 1
        st["gf"] += gf
        st["ga"] += ga
        self.place = 0
        if mode == "tour":
            t = s["tournament"]
            prize = data.finish_round(t, data.squad_rating(s), gf, ga)
            if t["done"]:
                self.place = t["place"]
                self.lines.append(("Turnir mukofoti (%d-o'rin)" % t["place"], prize))
                if t["place"] == 1:
                    s["titles"] += 1
        self.total = sum(v for _, v in self.lines)
        s["coins"] += self.total
        app.persist()
        self.res = res

    def handle(self, ev):
        if ev.type == KEYDOWN and ev.key in ENTER + (K_SPACE, K_ESCAPE):
            self.app.go(TournamentScene if self.mode == "tour" else MenuScene)

    def update(self, dt):
        pass

    def draw(self, surf):
        a = self.app
        background(surf, a.t)
        m = self.m
        head = {"win": "G'ALABA!", "draw": "DURRANG", "loss": "MAG'LUBIYAT"}[self.res]
        col = {"win": (120, 255, 150), "draw": (255, 230, 120), "loss": (255, 130, 130)}[self.res]
        text(surf, head, 80, col, (SW // 2, 90), "center", True, shadow=True)
        text(surf, "%s  %d - %d  %s" % (m.names[0], m.score[0], m.score[1], m.names[1]), 34,
             (255, 255, 255), (SW // 2, 170), "center", True)
        panel(surf, (380, 220, 520, 330), alpha=190)
        y = 245
        for k, v in self.lines:
            text(surf, k, 24, (200, 215, 235), (410, y))
            text(surf, "+%d" % v, 24, (255, 235, 150), (870, y), "topright", True)
            y += 44
        pygame.draw.line(surf, (90, 120, 170), (410, y + 6), (870, y + 6), 2)
        text(surf, "Jami", 28, (255, 255, 255), (410, y + 20), "topleft", True)
        text(surf, "+%d tanga" % self.total, 28, (255, 235, 150), (870, y + 20), "topright", True)
        if m.goals_log:
            text(surf, "Gollar: " + ", ".join("%s %d'" % (w, mn) for mn, tm, w in m.goals_log[:5]),
                 16, (170, 195, 225), (SW // 2, 580), "center")
        footer(surf, "Enter - davom etish")


# ------------------------------------------------------------------------- turnir
class TournamentScene:
    def __init__(self, app):
        self.app = app

    def handle(self, ev):
        if ev.type != KEYDOWN:
            return
        a = self.app
        t = a.save["tournament"]
        if ev.key == K_ESCAPE:
            a.go(MenuScene)
        elif ev.key in ENTER:
            if t is None or t["done"]:
                a.save["tournament"] = data.new_tournament()
                a.persist()
            else:
                o = data.next_opponent(t)
                tm = t["teams"][o]
                a.start_match(tm["name"], tm["color"], tm["rating"], "tour")

    def update(self, dt):
        pass

    def draw(self, surf):
        a = self.app
        t = a.save["tournament"]
        background(surf, a.t)
        title(surf, "Turnir", "6 jamoa, bitta davra - har biri bilan bitta o'yin")
        coins_badge(surf, a.save["coins"])
        if t is None:
            panel(surf, (340, 220, 600, 240), alpha=190)
            text(surf, "Yangi turnir boshlash", 36, (255, 255, 255), (SW // 2, 280), "center", True)
            text(surf, "Birinchi o'rin uchun %d tanga!" % data.PRIZES[0], 24, (255, 230, 120),
                 (SW // 2, 340), "center")
            text(surf, "Enter - boshlash", 24, (190, 210, 235), (SW // 2, 400), "center")
            footer(surf, "Esc - orqaga")
            return
        panel(surf, (60, 120, 760, 400), alpha=190)
        heads = ["#", "Jamoa", "O", "G", "D", "M", "To'p farqi", "Ochko"]
        xs = [80, 125, 420, 470, 520, 570, 650, 760]
        for h, x in zip(heads, xs):
            text(surf, h, 18, (150, 175, 210), (x, 135), "topleft", True)
        for pos, i in enumerate(data.standings(t)):
            tm, row = t["teams"][i], t["table"][i]
            y = 175 + pos * 55
            if i == 0:
                pygame.draw.rect(surf, (28, 100, 150), (70, y - 6, 740, 48), border_radius=10)
            vals = [pos + 1, None, row["p"], row["w"], row["d"], row["l"],
                    "%+d" % (row["gf"] - row["ga"]), row["pts"]]
            for v, x in zip(vals, xs):
                if v is None:
                    pygame.draw.rect(surf, tm["color"], (x, y + 4, 10, 28), border_radius=3)
                    text(surf, tm["name"], 22, (255, 255, 255), (x + 20, y + 4), "topleft", True)
                else:
                    text(surf, v, 22, (255, 255, 255), (x, y + 4), "topleft", True)
        panel(surf, (850, 120, 370, 400), alpha=190)
        if t["done"]:
            text(surf, "Turnir tugadi!", 30, (255, 230, 120), (1035, 160), "center", True)
            text(surf, "%d-o'rin" % t["place"], 56, (255, 255, 255), (1035, 240), "center", True)
            text(surf, "Mukofot: %d tanga" % t["prize"], 24, (255, 235, 150), (1035, 310), "center")
            text(surf, "Enter - yangi turnir", 22, (190, 210, 235), (1035, 460), "center")
        else:
            o = t["teams"][data.next_opponent(t)]
            text(surf, "Keyingi o'yin", 26, (255, 230, 120), (1035, 160), "center", True)
            text(surf, "Davra %d / %d" % (t["round"] + 1, len(t["schedule"])), 20, (190, 210, 235),
                 (1035, 195), "center")
            text(surf, data.USER_NAME, 26, (255, 255, 255), (1035, 250), "center", True)
            text(surf, "vs", 22, (150, 175, 210), (1035, 290), "center")
            pygame.draw.rect(surf, o["color"], (905, 326, 12, 40), border_radius=4)
            text(surf, o["name"], 26, (255, 255, 255), (1035, 345), "center", True)
            text(surf, "Reyting: %d" % o["rating"], 20, (190, 210, 235), (1035, 390), "center")
            text(surf, "Enter - o'ynash", 22, (190, 210, 235), (1035, 460), "center")
        footer(surf, "Enter - davom etish   |   Esc - orqaga")


# ------------------------------------------------------------------- jamoa tuzish
class SquadScene:
    def __init__(self, app):
        self.app = app
        self.slot = 0
        self.mode = "slots"
        self.idx = 0
        self.msg = ""

    def candidates(self):
        s = self.app.save
        used = {sid for i, sid in enumerate(s["squad"]) if i != self.slot}
        pos = data.SLOTS[self.slot]
        L = [c for c in s["cards"] if c["pos"] == pos and c["id"] not in used]
        L.sort(key=lambda c: -c["ovr"])
        return L

    def handle(self, ev):
        if ev.type != KEYDOWN:
            return
        a = self.app
        s = a.save
        k = ev.key
        self.msg = ""
        if self.mode == "slots":
            if k in (K_LEFT, K_a):
                self.slot = (self.slot - 1) % 5
            elif k in (K_RIGHT, K_d):
                self.slot = (self.slot + 1) % 5
            elif k in ENTER:
                self.mode = "list"
                L = self.candidates()
                cur = s["squad"][self.slot]
                self.idx = next((i for i, c in enumerate(L) if c["id"] == cur), 0)
            elif k == K_ESCAPE:
                a.go(MenuScene)
            elif k == pygame.K_b:
                data.best_squad(s)
                a.persist()
                self.msg = "Eng yaxshi tarkib tanlandi!"
                a.sfx.play("buy")
        else:
            L = self.candidates()
            if k in (K_LEFT, K_a) and L:
                self.idx = (self.idx - 1) % len(L)
            elif k in (K_RIGHT, K_d) and L:
                self.idx = (self.idx + 1) % len(L)
            elif k in ENTER and L:
                s["squad"][self.slot] = L[self.idx]["id"]
                a.persist()
                self.mode = "slots"
                a.sfx.play("buy")
            elif k == pygame.K_x and L:
                c = L[self.idx]
                if c["id"] in s["squad"]:
                    self.msg = "Tarkibdagi kartani sotib bo'lmaydi"
                else:
                    s["cards"] = [q for q in s["cards"] if q["id"] != c["id"]]
                    s["coins"] += data.sell_value(c)
                    a.persist()
                    self.msg = "Sotildi: +%d tanga" % data.sell_value(c)
                    self.idx = max(0, min(self.idx, len(L) - 2))
                    a.sfx.play("buy")
            elif k == K_ESCAPE:
                self.mode = "slots"

    def update(self, dt):
        pass

    def draw(self, surf):
        a = self.app
        s = a.save
        background(surf, a.t)
        title(surf, "Jamoa tuzish", "Jamoa reytingi: %d   |   Barcha kartalar: %d" %
              (data.squad_rating(s), len(s["cards"])))
        coins_badge(surf, s["coins"])
        by_id = {c["id"]: c for c in s["cards"]}
        x0 = (SW - (5 * 150 + 4 * 30)) // 2
        for i in range(5):
            c = by_id[s["squad"][i]]
            draw_card(surf, c, x0 + i * 180, 110, selected=(i == self.slot), label=data.SLOTS[i])
        if self.mode == "list":
            L = self.candidates()
            text(surf, "%s uchun kartalar (%d)" % (data.SLOTS[self.slot], len(L)), 22,
                 (255, 230, 120), (SW // 2, 372), "center", True)
            start = max(0, min(self.idx - 3, len(L) - 7))
            for j, c in enumerate(L[start:start + 7]):
                i = start + j
                draw_card(surf, c, 70 + j * 165, 400, w=145, h=198, selected=(i == self.idx),
                          dim=(c["id"] in s["squad"]))
            if L:
                c = L[self.idx]
                text(surf, "Sotish narxi: %d" % data.sell_value(c), 18, (190, 210, 235),
                     (SW - 40, 372), "topright")
        else:
            panel(surf, (240, 400, 800, 180), alpha=170)
            text(surf, "Tanlangan o'rin: %s" % data.SLOTS[self.slot], 26, (255, 255, 255),
                 (SW // 2, 440), "center", True)
            text(surf, "Enter - shu o'rin uchun karta tanlash", 22, (190, 210, 235),
                 (SW // 2, 490), "center")
            text(surf, "B - eng yaxshi tarkibni avtomatik tanlash", 22, (190, 210, 235),
                 (SW // 2, 530), "center")
        if self.msg:
            text(surf, self.msg, 24, (255, 235, 150), (SW // 2, 640), "center", True, shadow=True)
        if self.mode == "slots":
            footer(surf, "Chap/O'ng - o'rin   |   Enter - almashtirish   |   B - avto   |   Esc - orqaga")
        else:
            footer(surf, "Chap/O'ng - karta   |   Enter - tanlash   |   X - sotish   |   Esc - orqaga")


# ----------------------------------------------------------------------- do'kon
class ShopScene:
    def __init__(self, app):
        self.app = app
        self.sel = 0
        self.state = "list"
        self.cards = []
        self.shown = 0
        self.flash = 0.0
        self.msg = ""

    def items(self):
        its = ["%s  -  %d" % (p[0], p[1]) for p in data.PACKS]
        its.append("Kunlik sovg'a  +%d" % data.DAILY_GIFT if data.daily_available(self.app.save)
                   else "Kunlik sovg'a  (ertaga)")
        return its

    def handle(self, ev):
        if ev.type != KEYDOWN:
            return
        a = self.app
        s = a.save
        k = ev.key
        if self.state == "reveal":
            if k in ENTER or k == K_SPACE:
                if self.shown < 3:
                    self.shown += 1
                    self.flash = 1.0
                    a.sfx.play("reveal")
                else:
                    self.state = "list"
            return
        self.msg = ""
        if k in (K_UP, K_w):
            self.sel = (self.sel - 1) % 4
        elif k in (K_DOWN, K_s):
            self.sel = (self.sel + 1) % 4
        elif k == K_ESCAPE:
            a.go(MenuScene)
        elif k in ENTER:
            if self.sel == 3:
                if data.claim_daily(s):
                    a.persist()
                    a.sfx.play("buy")
                    self.msg = "+%d tanga olindi!" % data.DAILY_GIFT
                else:
                    self.msg = "Bugungi sovg'a allaqachon olingan"
            else:
                name, price, kind, col = data.PACKS[self.sel]
                if s["coins"] < price:
                    self.msg = "Tangalar yetarli emas"
                else:
                    s["coins"] -= price
                    self.cards = data.roll_pack(kind)
                    s["cards"].extend(self.cards)
                    a.persist()
                    self.state = "reveal"
                    self.shown = 0
                    a.sfx.play("buy")

    def update(self, dt):
        self.flash = max(0.0, self.flash - dt * 2.5)

    def draw(self, surf):
        a = self.app
        s = a.save
        background(surf, a.t)
        title(surf, "Do'kon", "Paket oching va yangi futbolchilarni toping")
        coins_badge(surf, s["coins"])
        if self.state == "reveal":
            for i in range(3):
                x = 250 + i * 270
                draw_card(surf, self.cards[i] if i < self.shown else None, x, 200, w=220, h=303,
                          back=(i >= self.shown), selected=(i == self.shown - 1))
            if self.flash > 0:
                ov = pygame.Surface((SW, SH), pygame.SRCALPHA)
                ov.fill((255, 255, 255, int(120 * self.flash)))
                surf.blit(ov, (0, 0))
            msg = "Enter - kartani ochish" if self.shown < 3 else "Enter - davom etish"
            text(surf, msg, 28, (255, 230, 120), (SW // 2, 590), "center", True, shadow=True)
            return
        draw_menu(surf, self.items(), self.sel, 400, 150, w=560)
        panel(surf, (760, 150, 460, 330), alpha=180)
        if self.sel < 3:
            name, price, kind, col = data.PACKS[self.sel]
            pygame.draw.rect(surf, col, (880, 175, 220, 150), border_radius=16)
            text(surf, "3 ta", 48, (30, 20, 10), (990, 250), "center", True)
            text(surf, "futbolchi", 24, (30, 20, 10), (990, 290), "center", True)
            text(surf, name, 28, (255, 255, 255), (990, 360), "center", True)
            text(surf, "Narxi: %d tanga" % price, 22, (255, 235, 150), (990, 400), "center")
            text(surf, ["Asosan bronza", "Kumush va oltin", "Oltin va elita"][kind], 20,
                 (190, 210, 235), (990, 435), "center")
        else:
            text(surf, "Har kuni bepul tanga!", 28, (255, 255, 255), (990, 290), "center", True)
        if self.msg:
            text(surf, self.msg, 26, (255, 235, 150), (400, 520), "center", True, shadow=True)
        footer(surf, "Yuqori/Past - tanlash   |   Enter - sotib olish   |   Esc - orqaga")


# -------------------------------------------------------------------- sozlamalar
class SettingsScene:
    def __init__(self, app):
        self.app = app
        self.sel = 0
        self.confirm = False

    def labels(self):
        st = self.app.save["settings"]
        return ["Qiyinlik: %s" % DIFF_NAMES[st["difficulty"]],
                "O'yin davomiyligi: %d soniya" % st["length"],
                "Ovoz: %s" % ("yoqilgan" if st["sound"] else "o'chirilgan"),
                "To'liq ekran (F11)",
                "Progressni o'chirish" if not self.confirm else "Ishonchingiz komilmi? Enter"]

    def change(self, d):
        a = self.app
        st = a.save["settings"]
        if self.sel == 0:
            st["difficulty"] = (st["difficulty"] + d) % 3
        elif self.sel == 1:
            i = LENGTHS.index(st["length"]) if st["length"] in LENGTHS else 2
            st["length"] = LENGTHS[(i + d) % len(LENGTHS)]
        elif self.sel == 2:
            st["sound"] = not st["sound"]
            a.sfx.enabled = st["sound"]
        a.persist()

    def handle(self, ev):
        if ev.type != KEYDOWN:
            return
        a = self.app
        k = ev.key
        if k != K_RETURN and k not in (K_KP_ENTER,):
            self.confirm = False if k != K_ESCAPE else self.confirm
        if k in (K_UP, K_w):
            self.sel = (self.sel - 1) % 5
        elif k in (K_DOWN, K_s):
            self.sel = (self.sel + 1) % 5
        elif k in (K_LEFT, K_a):
            self.change(-1)
        elif k in (K_RIGHT, K_d):
            self.change(1)
        elif k == K_ESCAPE:
            a.go(MenuScene)
        elif k in ENTER:
            if self.sel in (0, 1, 2):
                self.change(1)
            elif self.sel == 3:
                try:
                    pygame.display.toggle_fullscreen()
                except Exception:
                    pass
            elif self.sel == 4:
                if self.confirm:
                    keep = a.save["settings"]
                    a.save = data.new_save()
                    a.save["settings"] = keep
                    a.persist()
                    self.confirm = False
                else:
                    self.confirm = True

    def update(self, dt):
        pass

    def draw(self, surf):
        a = self.app
        background(surf, a.t)
        title(surf, "Sozlamalar", "Chap/O'ng yoki Enter - qiymatni o'zgartirish")
        draw_menu(surf, self.labels(), self.sel, SW // 2, 160, w=640)
        footer(surf, "Yuqori/Past - tanlash   |   Esc - orqaga")


def main():
    App().run()


if __name__ == "__main__":
    main()
