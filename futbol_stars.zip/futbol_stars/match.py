"""O'yin maydoni: fizika, sun'iy intellekt, boshqaruv va chizish."""
import math
import random

import pygame
from pygame.locals import (K_DOWN, K_ESCAPE, K_KP_ENTER, K_LEFT, K_LSHIFT, K_RETURN, K_RIGHT,
                           K_RSHIFT, K_SPACE, K_UP, K_a, K_d, K_j, K_k, K_l, K_p, K_q, K_s, K_w,
                           KEYDOWN, KEYUP)
from pygame.math import Vector2 as V

from data import SLOTS
from ui import draw_ball, panel, text

W, H = 1000, 560          # maydon o'lchami
OX, OY = 140, 108         # ekrandagi joylashuvi
GOAL_W, GOAL_D = 150, 26
PEN_D, PEN_H = 150, 320
GA_D, GA_H = 52, 170
PL_R, BALL_R = 11, 6
HOMES = [(0.03, 0.5), (0.24, 0.28), (0.24, 0.72), (0.46, 0.5), (0.70, 0.5)]

DIFF_AI = {
    0: dict(speed=0.90, think=0.30, noise=1.4, tackle=0.75, gk=0.90),
    1: dict(speed=1.00, think=0.22, noise=1.0, tackle=1.00, gk=1.00),
    2: dict(speed=1.06, think=0.16, noise=0.80, tackle=1.20, gk=1.08),
}
NORMAL = DIFF_AI[1]


def clampf(v, a, b):
    return a if v < a else b if v > b else v


def norm(v, default=(1, 0)):
    ln = v.length()
    if ln < 1e-6:
        return V(default)
    return v / ln


def seg_dist(p, a, b):
    ab = b - a
    l2 = ab.length_squared()
    if l2 == 0:
        return p.distance_to(a)
    t = clampf((p - a).dot(ab) / l2, 0, 1)
    return p.distance_to(a + ab * t)


def color_far(a, b):
    return sum((x - y) ** 2 for x, y in zip(a, b)) > 90 ** 2


_pitch = None


def build_pitch():
    global _pitch
    if _pitch is not None:
        return _pitch
    M = 60
    s = pygame.Surface((W + 2 * M, H + 2 * M))
    s.fill((14, 62, 34))
    n = 14
    sw = W / n
    for i in range(n):
        col = (34, 139, 58) if i % 2 == 0 else (39, 151, 65)
        pygame.draw.rect(s, col, (M + i * sw, M, sw + 1, H))
    wl = (236, 246, 236)
    pygame.draw.rect(s, wl, (M, M, W, H), 3)
    pygame.draw.line(s, wl, (M + W / 2, M), (M + W / 2, M + H), 3)
    pygame.draw.circle(s, wl, (M + W // 2, M + H // 2), 70, 3)
    pygame.draw.circle(s, wl, (M + W // 2, M + H // 2), 4)
    gy = (H - GOAL_W) / 2
    for side in (0, 1):
        x0 = 0 if side == 0 else W - PEN_D
        pygame.draw.rect(s, wl, (M + x0, M + (H - PEN_H) / 2, PEN_D, PEN_H), 3)
        gx0 = 0 if side == 0 else W - GA_D
        pygame.draw.rect(s, wl, (M + gx0, M + (H - GA_H) / 2, GA_D, GA_H), 3)
        px = 100 if side == 0 else W - 100
        pygame.draw.circle(s, wl, (M + px, M + H // 2), 3)
        nx = -GOAL_D if side == 0 else W
        net = pygame.Rect(M + nx, M + gy, GOAL_D, GOAL_W)
        pygame.draw.rect(s, (205, 212, 218), net)
        for k in range(0, GOAL_W, 10):
            pygame.draw.line(s, (150, 160, 170), (net.x, net.y + k), (net.right, net.y + k), 1)
        for k in range(0, GOAL_D, 9):
            pygame.draw.line(s, (150, 160, 170), (net.x + k, net.y), (net.x + k, net.bottom), 1)
        pygame.draw.rect(s, (255, 255, 255), net, 3)
    _pitch = s
    return s


class Pl:
    def __init__(self, team, idx, card):
        self.team = team
        self.idx = idx
        self.card = card
        self.role = card["pos"]
        self.home = HOMES[idx]
        self.pos = V(0, 0)
        self.vel = V(0, 0)
        self.want = V(0, 0)
        self.face = V(1, 0) if team == 0 else V(-1, 0)
        self.kick_cd = 0.0
        self.tackle_cd = 0.0
        self.slide = 0.0
        self.slide_cd = 0.0
        self.stun = 0.0
        self.think = random.random() * 0.2
        self.target = V(0, 0)
        self.hold = 0.0
        self.sprint = False
        self.stamina = 1.0
        self.roll_id = -1


class Match:
    def __init__(self, ucards, ocards, ucolor, ocolor, uname, oname, length, diff, sfx, auto=False):
        self.sfx = sfx
        self.length = float(length)
        self.diff = diff
        self.ai = DIFF_AI[diff]
        self.auto = auto
        self.names = [uname, oname]
        ucolor = tuple(ucolor)
        ocolor = tuple(ocolor)
        if not color_far(ucolor, ocolor):
            ocolor = (235, 235, 235) if sum(ucolor) < 600 else (205, 45, 45)
        self.colors = [ucolor, ocolor]
        self.players = [[Pl(0, i, c) for i, c in enumerate(ucards)],
                        [Pl(1, i, c) for i, c in enumerate(ocards)]]
        self.all = self.players[0] + self.players[1]
        self.ball = V(W / 2, H / 2)
        self.bvel = V(0, 0)
        self.ball_ang = 0.0
        self.owner = None
        self.last_team = 0
        self.last_pl = None
        self.score = [0, 0]
        self.shots = [0, 0]
        self.poss = [0.0, 0.0]
        self.clock = 0.0
        self.state = "kickoff"
        self.timer = 2.0
        self.banner = "BOSHLANISH"
        self.sub = ""
        self.half_done = False
        self.ctrl = None
        self.lock_t = 0.0
        self.charging = False
        self.charge = 0.0
        self.freeze = 0.0
        self.shot_id = 0
        self.pass_target = None
        self.paused = False
        self.pause_sel = 0
        self.finished = False
        self.quit = False
        self.kick_team = 0
        self.shake = 0.0
        self.input_dir = V(0, 0)
        self.confetti = []
        self.goals_log = []
        self.goal_kinds = []
        self.last_kick_shot = False
        self.pitch_s = build_pitch()
        self.reset_positions(0)

    # ------------------------------------------------------------ yordamchi
    def aiv(self, p):
        return self.ai if p.team == 1 else NORMAL

    def minute(self):
        return int(min(90, self.clock / self.length * 90))

    def prog(self, q):
        return q.pos.x if q.team == 0 else W - q.pos.x

    def reset_positions(self, kick_team):
        self.kick_team = kick_team
        self.owner = None
        self.bvel = V(0, 0)
        self.pass_target = None
        for team in (0, 1):
            for p in self.players[team]:
                fx, fy = p.home
                if p.role != "GK":
                    fx = min(fx, 0.44)
                x = fx * W if team == 0 else (1 - fx) * W
                p.pos = V(x, fy * H)
                p.vel = V(0, 0)
                p.want = V(0, 0)
                p.face = V(1, 0) if team == 0 else V(-1, 0)
                p.kick_cd = p.tackle_cd = p.slide = p.stun = p.hold = 0.0
                p.sprint = False
                p.target = V(p.pos)
        k = self.players[kick_team][4]
        k.pos = V(W / 2 - 12 if kick_team == 0 else W / 2 + 12, H / 2)
        k.target = V(k.pos)
        self.ball = V(k.pos + k.face * 15)
        self.charging = False
        self.charge = 0.0
        self.freeze = 0.0
        self.ctrl = k if kick_team == 0 else self.players[0][3]
        self.take(k)

    def take(self, p):
        self.owner = p
        self.last_team = p.team
        self.last_pl = p
        self.pass_target = None
        p.hold = 0.0
        p.vel = p.vel * 0.5
        if self.charging and self.ctrl is not p:
            self.charging = False
        self.lock_t = 0.0

    # ----------------------------------------------------------------- hodisalar
    def handle_event(self, ev):
        if ev.type == KEYDOWN:
            if self.state == "over":
                if ev.key in (K_RETURN, K_KP_ENTER, K_SPACE):
                    self.finished = True
                return
            if ev.key in (K_ESCAPE, K_p):
                self.paused = not self.paused
                self.pause_sel = 0
                return
            if self.paused:
                if ev.key in (K_UP, K_w, K_DOWN, K_s):
                    self.pause_sel = 1 - self.pause_sel
                elif ev.key in (K_RETURN, K_KP_ENTER, K_SPACE):
                    if self.pause_sel == 0:
                        self.paused = False
                    else:
                        self.quit = True
                return
            if self.state != "play" or self.auto:
                return
            if ev.key in (K_j, K_SPACE):
                self.act_pass_or_tackle()
            elif ev.key == K_k:
                if self.owner is self.ctrl and self.freeze <= 0:
                    self.charging = True
                    self.charge = 0.0
            elif ev.key in (K_q, K_l):
                self.switch_player()
        elif ev.type == KEYUP and ev.key == K_k:
            if self.charging and self.owner is self.ctrl and self.state == "play":
                self.human_shoot(self.ctrl)
            self.charging = False
            self.charge = 0.0

    def switch_player(self):
        cands = [p for p in self.players[0] if p.role != "GK" and p is not self.ctrl]
        if not cands:
            return
        self.ctrl = min(cands, key=lambda q: q.pos.distance_to(self.ball))
        self.lock_t = 1.2
        self.charging = False
        self.sfx.play("click")

    def act_pass_or_tackle(self):
        p = self.ctrl
        if self.owner is p:
            if self.freeze > 0:
                return
            d = norm(self.input_dir if self.input_dir.length_squared() > 0 else p.face)
            t = self.best_pass_target(p, d, True)
            if t:
                aim = t.pos + t.vel * 0.35
                dist = p.pos.distance_to(aim)
                self.kick(p, aim - p.pos, min(640, dist * 1.8 + 80), (100 - p.card["pas"]) * 0.06)
                self.pass_target = t
            else:
                self.kick(p, d, 380, (100 - p.card["pas"]) * 0.06)
        elif p.slide_cd <= 0 and p.stun <= 0:
            p.slide = 0.28
            p.slide_cd = 0.9
            self.sfx.play("tackle")

    # ------------------------------------------------------------------- zarbalar
    def kick(self, p, d, speed, noise=0.0, shot=False):
        d = norm(V(d), p.face)
        if noise:
            d = d.rotate(random.gauss(0, noise))
        self.owner = None
        self.bvel = d * speed
        self.ball = p.pos + d * (PL_R + BALL_R + 3)
        p.kick_cd = 0.35
        p.hold = 0.0
        self.last_team = p.team
        self.last_pl = p
        self.shot_id += 1
        self.pass_target = None
        self.last_kick_shot = shot
        if shot:
            self.shots[p.team] += 1
            self.sfx.play("shot")
        else:
            self.sfx.play("kick")

    def human_shoot(self, p):
        ch = min(1.0, self.charge)
        d = norm(self.input_dir if self.input_dir.length_squared() > 0 else p.face)
        gx = W if p.team == 0 else 0
        gd = V(gx, H / 2) - p.pos
        if gd.length() < 560 and d.dot(norm(gd)) > 0.55 and abs(d.x) > 0.2:
            t = (gx - p.pos.x) / d.x
            if t > 0:
                yh = p.pos.y + d.y * t
                lim = GOAL_W / 2 - 14
                ty = clampf(yh, H / 2 - lim, H / 2 + lim)
                d2 = norm(V(gx, ty) - p.pos)
                blend = 0.75 if abs(yh - H / 2) > lim else 0.35
                d = norm(d * (1 - blend) + d2 * blend)
        power = 520 + 400 * ch * (0.65 + p.card["sho"] / 285.0)
        over = max(0.0, self.charge - 0.95)
        noise = (100 - p.card["sho"]) * 0.10 + 2.0 + over * 40
        self.kick(p, d, power, noise, shot=True)

    def ai_shoot(self, p):
        ai = self.aiv(p)
        gx = W if p.team == 0 else 0
        lim = GOAL_W / 2 - 14
        ty = H / 2 + random.choice([-1, 1]) * random.uniform(18, lim)
        d = norm(V(gx, ty) - p.pos)
        power = 600 + p.card["sho"] * 3.6
        noise = (100 - p.card["sho"]) * 0.12 * ai["noise"] + 1.5
        self.kick(p, d, power, noise, shot=True)

    def ai_pass(self, p, t):
        ai = self.aiv(p)
        aim = t.pos + t.vel * 0.4
        dist = p.pos.distance_to(aim)
        self.kick(p, aim - p.pos, min(620, dist * 1.8 + 80),
                  (100 - p.card["pas"]) * 0.05 * ai["noise"])
        self.pass_target = t

    def best_pass_target(self, p, d, human):
        best, bs = None, -1e9
        opps = self.players[1 - p.team]
        for q in self.players[p.team]:
            if q is p or q.role == "GK":
                continue
            v = q.pos - p.pos
            dist = v.length()
            if dist < 45 or dist > 600:
                continue
            u = v / dist
            if human:
                dot = u.dot(d)
                if dot < 0.5:
                    continue
                s = dot * 3
            else:
                s = (self.prog(q) - self.prog(p)) / 200.0
            s -= dist / 700.0
            for o in opps:
                if seg_dist(o.pos, p.pos, q.pos) < 26:
                    s -= 2.0
                if o.pos.distance_to(q.pos) < 40:
                    s -= 1.0
            if s > bs:
                bs, best = s, q
        if best is not None and not human and bs < -1.0:
            return None
        return best

    def lane_blocked(self, a, b, team):
        for o in self.players[1 - team]:
            if seg_dist(o.pos, a, b) < 30:
                return True
        return False

    # ------------------------------------------------------------------- AI
    def home_pos(self, p, attacking):
        fx, fy = p.home
        bfx = self.ball.x / W if p.team == 0 else 1 - self.ball.x / W
        fx = fx + (bfx - 0.5) * 0.45 + (0.10 if attacking else -0.04)
        if p.role == "DEF":
            fx = min(fx, 0.55)
        fx = clampf(fx, 0.08, 0.92)
        fy = clampf(fy + (self.ball.y / H - 0.5) * 0.30, 0.08, 0.92)
        x = fx * W if p.team == 0 else (1 - fx) * W
        return V(x, fy * H)

    def ai_think_time(self, p):
        if p.role == "GK":
            return 0.08
        return self.aiv(p)["think"] + random.random() * 0.08

    def ai_decide(self, p):
        o = self.owner
        if p.role == "GK":
            self.gk_decide(p)
            return
        if o is p:
            if self.freeze > 0:
                p.target = V(p.pos)
                return
            self.carrier_decide(p)
            return
        has_team = o is not None and o.team == p.team
        opp_has = o is not None and not has_team
        skip = None if self.auto else self.ctrl
        mates = [q for q in self.players[p.team] if q.role != "GK" and q is not skip]
        ranks = sorted(mates, key=lambda q: q.pos.distance_to(self.ball))
        p.sprint = False
        if not has_team:
            chaser = ranks[0] if ranks else None
            if o is None and self.pass_target is not None and self.pass_target in mates:
                chaser = self.pass_target
            if p is chaser:
                if o is None:
                    p.target = self.ball + self.bvel * 0.25
                else:
                    p.target = o.pos + o.vel * 0.15
                p.sprint = True
                return
            if opp_has and len(ranks) > 1 and p is ranks[1]:
                goal = V(0 if p.team == 0 else W, H / 2)
                p.target = o.pos + norm(goal - o.pos) * 50
                p.sprint = True
                return
        p.target = self.home_pos(p, has_team)

    def carrier_decide(self, p):
        team = p.team
        goal = V(W if team == 0 else 0, H / 2)
        gd = p.pos.distance_to(goal)
        opps = self.players[1 - team]
        nearest = min(opps, key=lambda q: q.pos.distance_to(p.pos))
        nd = nearest.pos.distance_to(p.pos)
        if gd < 250 + p.card["sho"] * 1.2:
            prob = 0.5 if gd < 220 else 0.28
            if p.role == "DEF":
                prob *= 0.4
            if self.lane_blocked(p.pos, goal, team):
                prob *= 0.6
            if random.random() < prob:
                self.ai_shoot(p)
                return
        pressured = nd < 70
        if pressured or p.hold > 2.5 or random.random() < 0.10:
            t = self.best_pass_target(p, None, False)
            if t and (pressured or p.hold > 2.5 or random.random() < 0.6):
                self.ai_pass(p, t)
                return
        dirv = norm(goal - p.pos)
        perp = V(-dirv.y, dirv.x)
        for q in opps:
            v = q.pos - p.pos
            dd = v.length()
            if 0 < dd < 90 and v.dot(dirv) > 0:
                side = 1 if v.dot(perp) < 0 else -1
                dirv = dirv + perp * side * (1.0 - dd / 90.0) * 1.4
        dirv = norm(dirv)
        t = p.pos + dirv * 120
        p.target = V(clampf(t.x, 10, W - 10), clampf(t.y, 10, H - 10))
        p.sprint = p.stamina > 0.3

    def gk_decide(self, p):
        team = p.team
        gx = 20 if team == 0 else W - 20
        sign = 1 if team == 0 else -1
        p.sprint = False
        if self.owner is p:
            p.target = V(p.pos)
            if p.hold > 0.7 and self.freeze <= 0:
                t = self.best_pass_target(p, None, False)
                if t:
                    self.ai_pass(p, t)
                else:
                    self.kick(p, V(sign, random.uniform(-0.3, 0.3)), 520, 4)
            return
        b = self.ball
        dgoal = abs(b.x - gx)
        y = H / 2 + clampf((b.y - H / 2) * 0.30, -GOAL_W / 2 + 16, GOAL_W / 2 - 16)
        x = gx + sign * clampf(dgoal * 0.06, 0, 30)
        if self.owner is not None and self.owner.team != team and abs(self.owner.pos.x - gx) < 200:
            x += sign * 25
        # kelayotgan zarba
        if self.owner is None and self.bvel.length() > 380 and self.last_team != team \
                and self.bvel.x * sign < 0:
            dxg = gx - b.x
            # to'p tezligi 0.25^t qonuni bilan so'nadi, shuning uchun yo'nalish o'zgarmaydi
            reach = abs(dxg) * 1.386 / max(1.0, abs(self.bvel.x))
            if dxg * self.bvel.x > 0 and reach < 0.95:
                err = (100 - p.card["dfn"]) * 0.35
                yh = b.y + (self.bvel.y / self.bvel.x) * dxg + random.uniform(-err, err)
                y = clampf(yh, H / 2 - GOAL_W / 2 + 6, H / 2 + GOAL_W / 2 - 6)
                x = gx + sign * 8
                p.sprint = True
        elif self.owner is None and dgoal < 140 and self.bvel.length() < 120 \
                and abs(b.y - H / 2) < PEN_H / 2:
            p.target = V(b)
            p.sprint = True
            return
        p.target = V(x, y)

    def ai_player(self, p, dt):
        p.think -= dt
        if p.think <= 0:
            p.think = self.ai_think_time(p)
            self.ai_decide(p)
        d = p.target - p.pos
        dist = d.length()
        if dist > 6:
            dv = d / dist
            p.want = dv * self.speed_of(p) * min(1.0, dist / 40.0)
            p.face = norm(p.face.lerp(dv, min(1.0, dt * 12)), dv)
        else:
            p.want = V(0, 0)
            if self.owner is not p:
                tb = self.ball - p.pos
                if tb.length_squared() > 1:
                    p.face = norm(p.face.lerp(norm(tb), min(1.0, dt * 6)), p.face)

    # ------------------------------------------------------------------ harakat
    def speed_of(self, p):
        s = 130 + p.card["pac"] * 1.2
        if p.team == 1:
            s *= self.ai["speed"]
        if p.sprint:
            s *= 1.28
        if self.owner is p:
            s *= 0.94
        if p.slide > 0:
            s *= 1.5
        if p.stun > 0:
            s *= 0.35
        if p.role == "GK":
            s *= 1.5 if p.sprint else 0.9
        return s

    def choose_ctrl(self, dt):
        self.lock_t = max(0.0, self.lock_t - dt)
        o = self.owner
        if o is not None and o.team == 0 and o.role != "GK":
            self.ctrl = o
            return
        if self.lock_t > 0:
            return
        cands = [p for p in self.players[0] if p.role != "GK"]
        nearest = min(cands, key=lambda q: q.pos.distance_to(self.ball))
        cur = self.ctrl
        if cur is None or cur.role == "GK" or \
                nearest.pos.distance_to(self.ball) + 25 < cur.pos.distance_to(self.ball):
            self.ctrl = nearest

    def human_move(self, keys, dt):
        p = self.ctrl
        ix = (keys[K_d] or keys[K_RIGHT]) - (keys[K_a] or keys[K_LEFT])
        iy = (keys[K_s] or keys[pygame.K_DOWN]) - (keys[K_w] or keys[K_UP])
        d = V(ix, iy)
        p.sprint = bool((keys[K_LSHIFT] or keys[K_RSHIFT]) and p.stamina > 0.05)
        self.input_dir = d
        if d.length_squared() > 0:
            d = d.normalize()
            p.face = norm(p.face.lerp(d, min(1.0, dt * 14)), d)
            p.want = d * self.speed_of(p)
        else:
            p.want = V(0, 0)
        if self.charging:
            if self.owner is p:
                self.charge = min(1.15, self.charge + dt * 1.1)
            else:
                self.charging = False

    def move_players(self, dt):
        for p in self.all:
            want = p.want
            if p.slide > 0:
                want = norm(p.face) * self.speed_of(p)
            p.vel += (want - p.vel) * min(1.0, dt * 9)
            p.pos += p.vel * dt
            moving = want.length() > 10
            if p.sprint and moving:
                p.stamina = max(0.0, p.stamina - dt * 0.32)
            else:
                p.stamina = min(1.0, p.stamina + dt * 0.12)
            if p.stamina <= 0.02:
                p.sprint = False
            p.pos.x = clampf(p.pos.x, 4, W - 4)
            p.pos.y = clampf(p.pos.y, 4, H - 4)
        n = len(self.all)
        for i in range(n):
            a = self.all[i]
            for j in range(i + 1, n):
                b = self.all[j]
                d = b.pos - a.pos
                dist = d.length()
                if 0 < dist < 20:
                    push = (20 - dist) / 2
                    u = d / dist
                    a.pos -= u * push
                    b.pos += u * push

    # ------------------------------------------------------------------- to'p
    def gk_try(self, gk, spd):
        if self.last_team == gk.team:
            if spd < 430:
                self.take(gk)
                return True
            return False
        if spd < 150:
            self.take(gk)
            return True
        if gk.roll_id == self.shot_id:
            return False
        gk.roll_id = self.shot_id
        p = 0.82 + (gk.card["dfn"] - 60) / 150.0 - (spd - 600) / 2500.0
        p *= self.ai["gk"] if gk.team == 1 else (2.0 - self.ai["gk"])
        p = clampf(p, 0.20, 0.95)
        if random.random() < p:
            self.sfx.play("save")
            if spd < 560 or random.random() < 0.55:
                self.take(gk)
            else:
                sign = 1 if gk.team == 0 else -1
                d = norm(V(sign, random.choice([-1, 1]) * random.uniform(0.4, 1.2)))
                self.bvel = d * spd * 0.5
                self.ball = gk.pos + d * (PL_R + BALL_R + 4)
                self.last_team = gk.team
                self.last_pl = gk
                gk.kick_cd = 0.3
            return True
        return False

    def ball_update(self, dt):
        if self.owner is not None:
            o = self.owner
            tgt = o.pos + norm(o.face, (1, 0)) * 15
            self.ball += (tgt - self.ball) * min(1.0, dt * 30)
            self.bvel = V(o.vel)
            return
        self.ball += self.bvel * dt
        self.bvel *= math.pow(0.25, dt)
        spd = self.bvel.length()
        if spd < 4:
            self.bvel = V(0, 0)
            spd = 0
        self.ball_ang += spd * dt * 0.12
        best, bd = None, 1e9
        for p in self.all:
            if p.kick_cd > 0:
                continue
            d = p.pos.distance_to(self.ball)
            if p.role == "GK":
                near = d < 32 or ((p.pos.x - self.ball.x) / 50.0) ** 2 + \
                    ((p.pos.y - self.ball.y) / 56.0) ** 2 < 1.0
                if near and self.gk_try(p, spd):
                    return
                continue
            r = 24 if p.slide > 0 else 16
            if d >= r:
                continue
            if spd < 430 or (p.slide > 0 and spd < 520):
                if d < bd:
                    best, bd = p, d
            elif p.team != self.last_team and d < 14 and p.roll_id != self.shot_id:
                p.roll_id = self.shot_id
                self.bvel = self.bvel.rotate(random.uniform(-70, 70)) * 0.55
                self.last_team = p.team
                self.last_pl = p
                p.kick_cd = 0.25
                self.sfx.play("tackle")
        if best is not None:
            self.take(best)

    def check_tackles(self):
        o = self.owner
        if o is None:
            return
        for p in self.players[1 - o.team]:
            if p.tackle_cd > 0 or p.stun > 0:
                continue
            reach = 21 + (10 if p.slide > 0 else 0)
            if p.pos.distance_to(o.pos) < reach:
                p.tackle_cd = 0.55
                prob = 0.30 + (p.card["dfn"] - (o.card["pac"] + o.card["pas"]) / 2.0) / 220.0
                if p.slide > 0:
                    prob += 0.28
                if p.team == 1:
                    prob *= self.ai["tackle"]
                if random.random() < clampf(prob, 0.08, 0.75):
                    self.bvel = V(0, 0)
                    o.kick_cd = 0.5
                    o.stun = 0.25
                    self.take(p)
                    self.sfx.play("tackle")
                    return
                p.vel *= 0.5

    def check_boundaries(self):
        if self.owner is not None:
            return
        b = self.ball
        if 0 <= b.x <= W and 0 <= b.y <= H:
            return
        in_goal = abs(b.y - H / 2) < GOAL_W / 2
        if (b.x < 0 or b.x > W) and in_goal:
            team = 0 if b.x > W else 1
            gk = [q for q in self.players[1 - team] if q.role == "GK"][0]
            # oxirgi imkoniyat: darvozabon sakrab to'pni ushlashga urinadi
            if self.last_team == team and gk.roll_id != self.shot_id and abs(gk.pos.y - b.y) < 70:
                if self.gk_try(gk, max(self.bvel.length(), 200.0)):
                    return
            self.goal(team)
            return
        if b.x < 0 or b.x > W:
            left = b.x < 0
            defender = 0 if left else 1
            if self.last_team == defender:
                team = 1 - defender
                pos = V(8 if left else W - 8, 8 if b.y < H / 2 else H - 8)
                self.restart(team, pos)
            else:
                self.restart(defender, V(36 if left else W - 36, H / 2), gk=True)
            return
        pos = V(clampf(b.x, 25, W - 25), 8 if b.y < 0 else H - 8)
        self.restart(1 - self.last_team, pos)

    def restart(self, team, pos, gk=False):
        if gk:
            cand = [p for p in self.players[team] if p.role == "GK"]
        else:
            cand = [p for p in self.players[team] if p.role != "GK"]
        p = min(cand, key=lambda q: q.pos.distance_to(pos))
        p.pos = V(pos)
        p.vel = V(0, 0)
        p.face = norm(V(W / 2, H / 2) - pos) if not gk else V(1 if team == 0 else -1, 0)
        p.kick_cd = 0
        self.ball = V(pos)
        self.bvel = V(0, 0)
        self.take(p)
        self.freeze = 0.7
        if team == 0 and not gk:
            self.ctrl = p
        self.sfx.play("click")

    def goal(self, team):
        self.score[team] += 1
        self.state = "goal"
        self.timer = 3.0
        self.banner = "GOL!"
        lp = self.last_pl
        if lp is not None and lp.team == team:
            who = lp.card["name"]
        else:
            who = "o'z darvozasiga"
        self.sub = "%s  %d'" % (who, self.minute())
        self.goals_log.append((self.minute(), team, who))
        self.goal_kinds.append(bool(self.last_kick_shot))
        self.kick_team = 1 - team
        self.owner = None
        self.shake = 0.4
        self.charging = False
        self.sfx.play("goal")
        col = self.colors[team]
        for _ in range(90):
            self.confetti.append([W / 2 + random.uniform(-300, 300), random.uniform(-40, 60),
                                  random.uniform(-60, 60), random.uniform(60, 220),
                                  random.choice([col, (255, 230, 60), (255, 255, 255), (255, 90, 90)]),
                                  random.uniform(1.5, 3.0)])

    # --------------------------------------------------------------- yangilash
    def update(self, dt, keys):
        if self.paused or self.state == "over":
            return
        self.shake = max(0.0, self.shake - dt)
        for c in self.confetti:
            c[0] += c[2] * dt
            c[1] += c[3] * dt
            c[5] -= dt
        self.confetti = [c for c in self.confetti if c[5] > 0]
        if self.state == "kickoff":
            self.timer -= dt
            if self.timer <= 0:
                self.state = "play"
                self.banner = ""
                self.sfx.play("whistle")
            return
        if self.state in ("goal", "half"):
            self.timer -= dt
            if self.state == "goal":
                self.ball += self.bvel * dt
                self.bvel *= math.pow(0.1, dt)
                self.ball.x = clampf(self.ball.x, -GOAL_D + 5, W + GOAL_D - 5)
            if self.timer <= 0:
                self.reset_positions(self.kick_team)
                self.state = "kickoff"
                self.timer = 1.6
                self.banner = "BOSHLANISH"
                self.sub = ""
            return
        # ---- o'yin
        self.clock += dt
        if self.owner is not None:
            self.poss[self.owner.team] += dt
            self.owner.hold += dt
        self.freeze = max(0.0, self.freeze - dt)
        for p in self.all:
            p.kick_cd = max(0.0, p.kick_cd - dt)
            p.tackle_cd = max(0.0, p.tackle_cd - dt)
            p.slide_cd = max(0.0, p.slide_cd - dt)
            p.stun = max(0.0, p.stun - dt)
            if p.slide > 0:
                p.slide -= dt
                if p.slide <= 0:
                    p.stun = max(p.stun, 0.35)
        if not self.auto:
            self.choose_ctrl(dt)
            self.human_move(keys, dt)
        for p in self.all:
            if self.auto or p is not self.ctrl:
                self.ai_player(p, dt)
        self.move_players(dt)
        self.ball_update(dt)
        self.check_tackles()
        self.check_boundaries()
        if self.state != "play":
            return
        if not self.half_done and self.clock >= self.length / 2:
            self.half_done = True
            self.state = "half"
            self.timer = 2.0
            self.banner = "TANAFFUS"
            self.sub = ""
            self.kick_team = 1
            self.sfx.play("whistle")
        elif self.clock >= self.length:
            self.state = "over"
            self.banner = "O'YIN TUGADI"
            self.owner = None
            self.sfx.play("whistle")

    # ----------------------------------------------------------------- chizish
    def draw_player(self, surf, p, ox, oy):
        x, y = ox + p.pos.x, oy + p.pos.y
        pygame.draw.ellipse(surf, (12, 44, 24), (int(x - 11), int(y + 5), 22, 10))
        if p.role == "GK":
            col = (240, 210, 60) if p.team == 0 else (120, 230, 160)
        else:
            col = self.colors[p.team]
        pygame.draw.circle(surf, (18, 18, 18), (int(x), int(y)), PL_R + 1)
        pygame.draw.circle(surf, col, (int(x), int(y)), PL_R)
        f = norm(p.face)
        pygame.draw.circle(surf, (250, 222, 184), (int(x + f.x * 6), int(y + f.y * 6)), 4)
        if p.slide > 0:
            pygame.draw.circle(surf, (255, 255, 255), (int(x), int(y)), PL_R + 5, 2)
        if p is self.ctrl and not self.auto:
            pygame.draw.circle(surf, (255, 230, 60), (int(x), int(y)), PL_R + 4, 2)
            pygame.draw.polygon(surf, (255, 230, 60),
                                [(x - 7, y - 28), (x + 7, y - 28), (x, y - 18)])
            text(surf, p.card["name"], 15, (255, 255, 255), (x, y + 24), "midtop", True, shadow=True)
            if self.charging:
                ch = min(1.0, self.charge)
                pygame.draw.rect(surf, (20, 20, 20), (x - 22, y - 42, 44, 8), border_radius=3)
                c = (int(80 + 175 * ch), int(220 - 140 * ch), 60)
                pygame.draw.rect(surf, c, (x - 21, y - 41, int(42 * ch), 6), border_radius=3)

    def draw(self, surf):
        surf.fill((12, 40, 24))
        sh = V(0, 0)
        if self.shake > 0:
            sh = V(random.uniform(-4, 4), random.uniform(-4, 4)) * (self.shake / 0.4)
        ox, oy = OX + sh.x, OY + sh.y
        surf.blit(self.pitch_s, (ox - 60, oy - 60))
        for p in sorted(self.all, key=lambda q: q.pos.y):
            self.draw_player(surf, p, ox, oy)
        bx, by = ox + self.ball.x, oy + self.ball.y
        pygame.draw.ellipse(surf, (12, 44, 24), (int(bx - 6), int(by + 3), 12, 6))
        draw_ball(surf, bx, by, BALL_R, self.ball_ang)
        for c in self.confetti:
            pygame.draw.rect(surf, c[4], (int(ox + c[0]), int(oy + c[1]), 6, 4))
        self.draw_hud(surf)
        if self.banner and self.state in ("kickoff", "goal", "half", "over"):
            panel(surf, (0, 285, 1280, 110 if self.sub else 90), alpha=140, radius=0, width=0)
            col = (255, 230, 70) if self.state == "goal" else (255, 255, 255)
            text(surf, self.banner, 70, col, (640, 325), "center", True, shadow=True)
            if self.sub:
                text(surf, self.sub, 28, (230, 240, 255), (640, 375), "center", True, shadow=True)
        if self.state == "over":
            self.draw_over(surf)
        if self.paused:
            self.draw_pause(surf)

    def draw_hud(self, surf):
        panel(surf, (290, 10, 700, 72), alpha=205)
        pygame.draw.rect(surf, self.colors[0], (306, 26, 10, 40), border_radius=4)
        pygame.draw.rect(surf, self.colors[1], (964, 26, 10, 40), border_radius=4)
        text(surf, self.names[0], 26, (255, 255, 255), (530, 46), "midright", True)
        text(surf, self.names[1], 26, (255, 255, 255), (750, 46), "midleft", True)
        text(surf, self.score[0], 50, (255, 255, 255), (572, 46), "center", True)
        text(surf, self.score[1], 50, (255, 255, 255), (708, 46), "center", True)
        label = "TANAFFUS" if self.state == "half" else "%d'" % self.minute()
        text(surf, label, 26, (255, 230, 120), (640, 38), "center", True)
        text(surf, "VAQT", 13, (150, 170, 200), (640, 62), "center")
        if self.ctrl is not None and not self.auto:
            text(surf, "KUCH", 14, (190, 205, 225), (24, 686), "midleft", True)
            pygame.draw.rect(surf, (20, 30, 40), (72, 679, 120, 14), border_radius=6)
            st = self.ctrl.stamina
            pygame.draw.rect(surf, (int(230 - 150 * st), int(80 + 150 * st), 70),
                             (73, 680, int(118 * st), 12), border_radius=5)
        text(surf, "WASD/strelkalar: yurish  |  J/Space: pas yoki to'siq  |  K (bosib turing): zarba  |  "
                   "Shift: tez yugurish  |  Q: o'yinchi almashtirish  |  Esc: pauza",
             15, (200, 215, 235), (640, 700), "midtop")

    def draw_over(self, surf):
        panel(surf, (380, 410, 520, 250), alpha=225)
        text(surf, "%s  %d - %d  %s" % (self.names[0], self.score[0], self.score[1], self.names[1]),
             26, (255, 255, 255), (640, 440), "center", True)
        tot = max(0.01, self.poss[0] + self.poss[1])
        text(surf, "Zarbalar: %d - %d" % (self.shots[0], self.shots[1]), 22, (200, 215, 235),
             (640, 490), "center")
        text(surf, "To'p egallash: %d%% - %d%%" % (round(100 * self.poss[0] / tot),
                                                   round(100 * self.poss[1] / tot)),
             22, (200, 215, 235), (640, 525), "center")
        text(surf, "Enter - davom etish", 24, (255, 230, 120), (640, 600), "center", True)

    def draw_pause(self, surf):
        ov = pygame.Surface((1280, 720), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 150))
        surf.blit(ov, (0, 0))
        panel(surf, (440, 230, 400, 250), alpha=235)
        text(surf, "PAUZA", 44, (255, 255, 255), (640, 270), "center", True)
        for i, it in enumerate(["Davom etish", "Menyuga chiqish"]):
            r = pygame.Rect(0, 0, 320, 50)
            r.center = (640, 340 + i * 62)
            if i == self.pause_sel:
                pygame.draw.rect(surf, (28, 150, 96), r, border_radius=12)
                pygame.draw.rect(surf, (255, 255, 255), r, 3, border_radius=12)
            else:
                panel(surf, r, alpha=150, radius=12)
            text(surf, it, 24, (255, 255, 255), r.center, "center", True)
