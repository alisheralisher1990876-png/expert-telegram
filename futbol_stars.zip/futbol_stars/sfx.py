"""Oddiy sintez qilingan ovozlar (tashqi fayllar kerak emas)."""
import array
import math
import random

import pygame


class Sfx:
    def __init__(self):
        self.ok = False
        self.enabled = True
        self.s = {}
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(22050, -16, 1, 512)
            self.ok = True
            self.s["click"] = self._seq([(880, 0.035, "sine")], 0.25)
            self.s["kick"] = self._seq([(150, 0.07, "noise")], 0.5)
            self.s["shot"] = self._seq([(110, 0.12, "noise")], 0.75)
            self.s["tackle"] = self._seq([(90, 0.09, "noise")], 0.5)
            self.s["save"] = self._seq([(300, 0.05, "sine"), (180, 0.09, "noise")], 0.55)
            self.s["whistle"] = self._seq(
                [(2500, 0.16, "trill"), (0, 0.04, "sine"), (2500, 0.30, "trill")], 0.28)
            self.s["goal"] = self._seq(
                [(523, 0.11, "sine"), (659, 0.11, "sine"), (784, 0.11, "sine"),
                 (1047, 0.40, "sine")], 0.35)
            self.s["buy"] = self._seq([(660, 0.07, "sine"), (880, 0.12, "sine")], 0.3)
            self.s["reveal"] = self._seq([(440, 0.06, "sine"), (880, 0.06, "sine"),
                                          (1320, 0.16, "sine")], 0.3)
        except Exception:
            self.ok = False

    def _seq(self, notes, vol):
        rate = 22050
        buf = array.array("h")
        for f, dur, kind in notes:
            n = int(rate * dur)
            for i in range(n):
                t = i / rate
                if kind == "noise":
                    env = (1.0 - i / n) ** 2
                    v = random.uniform(-1, 1) * 0.6 + math.sin(2 * math.pi * f * t) * 0.6
                elif kind == "trill":
                    env = min(1.0, i / 150, (n - i) / 300)
                    v = math.sin(2 * math.pi * f * t + 3 * math.sin(2 * math.pi * 38 * t))
                else:
                    env = min(1.0, i / 150, (n - i) / 300)
                    v = math.sin(2 * math.pi * f * t) if f else 0.0
                buf.append(int(32767 * vol * env * max(-1, min(1, v))))
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def play(self, name):
        if self.ok and self.enabled:
            snd = self.s.get(name)
            if snd:
                snd.play()
