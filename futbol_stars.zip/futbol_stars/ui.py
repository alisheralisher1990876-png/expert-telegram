"""Chizish yordamchilari: shriftlar, panellar, kartalar, menyular."""
import math

import pygame

from data import RAR_COL, rarity

SW, SH = 1280, 720

_fonts = {}
_cache = {}
_bg = None
_ov = None


def font(size, bold=False):
    k = (size, bold)
    if k not in _fonts:
        try:
            f = pygame.font.SysFont("dejavusans,arial,helvetica,liberationsans", size, bold=bold)
        except Exception:
            f = pygame.font.Font(None, size)
        _fonts[k] = f
    return _fonts[k]


def render(txt, size, color, bold=False):
    key = (txt, size, tuple(color), bold)
    s = _cache.get(key)
    if s is None:
        s = font(size, bold).render(txt, True, tuple(color))
        if len(_cache) > 800:
            _cache.clear()
        _cache[key] = s
    return s


def text(surf, txt, size, color, pos, anchor="topleft", bold=False, shadow=False):
    s = render(str(txt), size, color, bold)
    r = s.get_rect(**{anchor: (int(pos[0]), int(pos[1]))})
    if shadow:
        surf.blit(render(str(txt), size, (0, 0, 0), bold), r.move(2, 2))
    surf.blit(s, r)
    return r


def panel(surf, rect, alpha=175, color=(10, 20, 40), border=(70, 100, 150), radius=16, width=2):
    rect = pygame.Rect(rect)
    s = pygame.Surface(rect.size, pygame.SRCALPHA)
    pygame.draw.rect(s, (*color, alpha), s.get_rect(), border_radius=radius)
    if width:
        pygame.draw.rect(s, (*border, 255), s.get_rect(), width, border_radius=radius)
    surf.blit(s, rect.topleft)


def background(surf, t=0.0):
    global _bg, _ov
    if _bg is None:
        _bg = pygame.Surface((SW, SH))
        for y in range(SH):
            k = y / SH
            pygame.draw.line(_bg, (int(8 + 8 * k), int(26 + 60 * k), int(56 - 10 * k)), (0, y), (SW, y))
        _ov = pygame.Surface((SW, SH), pygame.SRCALPHA)
    surf.blit(_bg, (0, 0))
    _ov.fill((0, 0, 0, 0))
    for i in range(6):
        x = (i * 280 + t * 22) % (SW + 400) - 300
        pygame.draw.polygon(_ov, (255, 255, 255, 9),
                            [(x, SH), (x + 140, SH), (x + 480, 0), (x + 340, 0)])
    surf.blit(_ov, (0, 0))


def draw_ball(surf, x, y, r, ang=0.0):
    pygame.draw.circle(surf, (250, 250, 250), (int(x), int(y)), r)
    pygame.draw.circle(surf, (30, 30, 30), (int(x), int(y)), r, 2)
    for k in range(3):
        a = ang + k * 2.094
        pygame.draw.circle(surf, (40, 40, 40),
                           (int(x + math.cos(a) * r * 0.5), int(y + math.sin(a) * r * 0.5)),
                           max(2, r // 4))


def draw_card(surf, c, x, y, w=150, h=205, selected=False, dim=False, back=False, label=None):
    s = w / 150.0
    r = pygame.Rect(int(x), int(y), int(w), int(h))
    if back:
        pygame.draw.rect(surf, (20, 40, 90), r, border_radius=int(14 * s))
        pygame.draw.rect(surf, (90, 140, 230), r.inflate(-10, -10), 3, border_radius=int(11 * s))
        text(surf, "?", int(70 * s), (120, 170, 255), r.center, "center", True)
        if selected:
            pygame.draw.rect(surf, (255, 230, 60), r, 4, border_radius=int(14 * s))
        return
    col = RAR_COL[rarity(c["ovr"])]
    dark = tuple(int(v * 0.45) for v in col)
    mid = tuple(int(v * 0.78) for v in col)
    pygame.draw.rect(surf, dark, r, border_radius=int(14 * s))
    inner = r.inflate(-6, -6)
    pygame.draw.rect(surf, mid, inner, border_radius=int(12 * s))
    top = pygame.Rect(inner.x, inner.y, inner.w, int(inner.h * 0.5))
    pygame.draw.rect(surf, col, top, border_top_left_radius=int(12 * s),
                     border_top_right_radius=int(12 * s))
    ink = (28, 20, 10)
    text(surf, c["ovr"], int(44 * s), ink, (r.x + 14 * s, r.y + 8 * s), "topleft", True)
    text(surf, c["pos"], int(21 * s), ink, (r.x + 16 * s, r.y + 56 * s), "topleft", True)
    cx = r.x + w * 0.64
    pygame.draw.circle(surf, tuple(int(v * 0.55) for v in col), (int(cx), int(r.y + h * 0.27)), int(17 * s))
    pygame.draw.ellipse(surf, tuple(int(v * 0.55) for v in col),
                        (int(cx - 30 * s), int(r.y + h * 0.37), int(60 * s), int(46 * s)))
    pygame.draw.line(surf, ink, (r.x + 10 * s, r.y + h * 0.63), (r.right - 10 * s, r.y + h * 0.63), 2)
    text(surf, c["name"], int(18 * s), ink, (r.centerx, r.y + h * 0.69), "center", True)
    d4 = "SAV" if c["pos"] == "GK" else "DEF"
    rows = [("PAC", c["pac"], "SHO", c["sho"]), ("PAS", c["pas"], d4, c["dfn"])]
    for i, (a, av, b, bv) in enumerate(rows):
        yy = r.y + h * (0.79 + i * 0.105)
        text(surf, "%s %d" % (a, av), int(15 * s), ink, (r.x + w * 0.12, yy), "topleft", True)
        text(surf, "%s %d" % (b, bv), int(15 * s), ink, (r.x + w * 0.54, yy), "topleft", True)
    if dim:
        ov = pygame.Surface(r.size, pygame.SRCALPHA)
        pygame.draw.rect(ov, (0, 0, 0, 120), ov.get_rect(), border_radius=int(14 * s))
        surf.blit(ov, r.topleft)
    if selected:
        pygame.draw.rect(surf, (255, 230, 60), r, 4, border_radius=int(14 * s))
    if label:
        text(surf, label, 16, (230, 240, 255), (r.centerx, r.bottom + 6), "midtop", True)


def draw_menu(surf, items, sel, cx, y, w=460, h=54, gap=12):
    """items: matnlar ro'yxati. Rect'lar ro'yxatini qaytaradi."""
    rects = []
    for i, it in enumerate(items):
        r = pygame.Rect(0, 0, w, h)
        r.midtop = (cx, y + i * (h + gap))
        rects.append(r)
        if i == sel:
            pygame.draw.rect(surf, (28, 150, 96), r, border_radius=14)
            pygame.draw.rect(surf, (255, 255, 255), r, 3, border_radius=14)
            col = (255, 255, 255)
        else:
            panel(surf, r, alpha=150, radius=14)
            col = (200, 215, 235)
        text(surf, it, 26, col, r.center, "center", True)
    return rects


def footer(surf, msg):
    panel(surf, (0, SH - 40, SW, 40), alpha=190, radius=0, width=0)
    text(surf, msg, 18, (190, 205, 225), (SW // 2, SH - 20), "center")


def coins_badge(surf, coins):
    panel(surf, (SW - 250, 14, 236, 44), alpha=200, radius=22)
    pygame.draw.circle(surf, (240, 190, 40), (SW - 226, 36), 14)
    pygame.draw.circle(surf, (190, 140, 20), (SW - 226, 36), 14, 3)
    text(surf, "%d" % coins, 26, (255, 235, 150), (SW - 24, 36), "midright", True)


def title(surf, txt, sub=None):
    text(surf, txt, 46, (255, 255, 255), (40, 24), "topleft", True, shadow=True)
    if sub:
        text(surf, sub, 20, (170, 195, 225), (42, 78), "topleft")
