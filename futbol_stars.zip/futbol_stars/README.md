# Futbol Stars

Pygame'da yozilgan to'liq futbol o'yini (mobil futbol o'yinlari uslubida). Barcha futbolchilar va klublar to'qima.

## Ishga tushirish (kompyuterda)

1. Python 3.9+ o'rnating (python.org)
2. Kutubxonani o'rnating:  `pip install -r requirements.txt`
3. O'yinni ishga tushiring:  `python main.py`

## Imkoniyatlar

- **Tezkor o'yin** - 8 ta jamoadan birini tanlab o'ynang, 3 qiyinlik darajasi
- **Turnir** - 6 jamoa, har biri bilan bitta o'yin, o'rinlar uchun mukofot
- **Jamoa tuzish** - GK, 2 DEF, MID, FWD o'rinlariga kartalar tanlash, ortiqchasini sotish
- **Do'kon** - Bronza / Kumush / Oltin paketlar, kunlik bepul tanga
- **Sozlamalar** - qiyinlik, o'yin davomiyligi, ovoz, to'liq ekran
- Progress avtomatik saqlanadi (`~/.futbol_stars_save.json`)

## Boshqaruv

| Tugma | Amal |
|---|---|
| WASD / strelkalar | Yurish |
| J yoki Space | Pas (to'pda) / to'siq olish (to'psiz) |
| K (bosib turing, qo'yib yuboring) | Zarba - qancha uzoq bossangiz, shuncha kuchli |
| Shift | Tez yugurish (kuch sarflanadi) |
| Q | O'yinchini almashtirish |
| Esc / P | Pauza |
| F11 | To'liq ekran |

## .exe dastur qilish (ixtiyoriy)

```
pip install pyinstaller
pyinstaller --onefile --windowed --name FutbolStars main.py
```
Tayyor fayl `dist/` papkasida paydo bo'ladi.

## Fayllar

- `main.py` - menyu va sahnalar
- `match.py` - o'yin maydoni, fizika, sun'iy intellekt
- `data.py` - kartalar, jamoalar, saqlash, turnir
- `ui.py`, `sfx.py` - interfeys va ovozlar
